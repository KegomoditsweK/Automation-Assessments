package training.PageObjects;

import com.mysql.cj.protocol.Resultset;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import training.WebUtilities.WebActions;
import training.textFile.textFile;
import training.webPageObjects.*;
import java.io.*;
import java.sql.ResultSet;
import java.time.Duration;

public class WebFunctions  extends WebActions {


    public void Login(WebDriver driver, ResultSet rs)  {
        loginAdactin log = new loginAdactin(driver);

        try {

            driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));

            passData(log.txtUsernme, driver ,rs.getString("Username"));
            passData(log.txtPassword, driver ,rs.getString("Password") );
            clickObject(log.btnLogin,driver);

            if(!driver.getCurrentUrl().contains("SearchHotel")){
                System.out.println("Invalid Login details or Your Password might have expired.");
            }
            else {
                System.out.println("Logged In Successfully.");
            }
        }catch (Exception e) {
            System.out.println("Login unsuccessful,Errors"+e.getMessage());
        }
    }

    //Scenario 1
    public  void search (WebDriver driver,  ResultSet rs) throws Exception{
        searchHotel search = new searchHotel(driver);

        try {

            driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));

            selectObject(search.location,driver ,"selectByVisibleText", rs.getString("Location"));
            selectObject(search.hotels, driver,"selectByVisibleText",rs.getString("Hotels"));
            selectObject(search.room_type,driver, "selectByVisibleText",rs.getString("RoomType"));
            selectObject(search.room_no, driver,"selectByVisibleText", rs.getString("NumberOfRooms"));
            passData(search.check_in_date, driver ,rs.getString("CheckInDate"));
            passData(search.check_out_date, driver, rs.getString("CheckOutDate"));
            selectObject(search.adults, driver, "selectByVisibleText", rs.getString("AdultsPerRoom"));
            selectObject(search.children, driver, "selectByVisibleText", rs.getString("ChildrenPerRoom"));
            clickObject(search.submit,driver);

        } catch (Exception e) {
            System.out.println("search was unsuccessful,Errors" + e.getMessage());
        }
    }


    public  void sel_Hotel(WebDriver driver) {
        selectHotel selectObj = new selectHotel(driver);
        try{

            driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));

            clickObject(selectObj.radioBtnSel, driver);
            clickObject(selectObj.btnSelCont,driver);
        }catch (Exception e) {
            System.out.println("Select hotel was unsuccessful,Errors" + e.getMessage());
        }
    }

    public  void Book_hotel (WebDriver driver, ResultSet rs) throws IOException {
        bookHotel bookHotel = new bookHotel(driver);
        searchOrder orderSearch = new searchOrder(driver);
        try {

            driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));

            passData(bookHotel.firstname, driver, rs.getString("FirstName"));
            passData(bookHotel.surname, driver, rs.getString("LastName"));
            passData(bookHotel.billing, driver, rs.getString("BillingAddress"));
            passData(bookHotel.account, driver,rs.getString("CreditCardNumber"));
            selectObject(bookHotel.account_type, driver, "selectByVisibleText",rs.getString("CreditCardType"));
            selectObject(bookHotel.month, driver, "selectByVisibleText", rs.getString("ExpiryDateMonth"));
            selectObject(bookHotel.year, driver, "selectByVisibleText", rs.getString("ExpiryDateYear"));
            passData(bookHotel.cvv, driver,rs.getString("CVVNumber"));
            clickObject(bookHotel.bookNowButton, driver);

           // WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
            //wait.until(ExpectedConditions.visibilityOf(orderSearch.orderNumber));
           //String order =orderSearch.orderNumber.getAttribute("value");


        }
        catch (Exception e) {
            System.out.println(" book unsuccessfully booked,Errors" + e.getMessage());
        }
    }

    public void orderNumGenerated(WebDriver driver) throws IOException {
        textFile fileHandler = new textFile();
        searchOrder orderSearch = new searchOrder(driver);

        String orderNum;

        try {
            driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));

            orderNum = orderSearch.orderNumber.getAttribute("value");
            fileHandler.writeToFile(orderNum);


        } catch (Exception e) {
            e.printStackTrace();
        }
    }


//Scenario 2
    public void BookedItinerary(WebDriver driver){
        itinerary item = new itinerary(driver);
        item.btnBookedItinerary.click();
    }

    public void SearchOrderNumber(WebDriver driver) throws  Exception {

        textFile fileHandler = new textFile();
        searchOrder orderSearch = new searchOrder(driver);
        String orderNumber = "";


        try{
            driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

            orderNumber = fileHandler.readFromFile();

            System.out.println("Order number stored: "+orderNumber);
            Thread.sleep(5000);

            passData(orderSearch.txtOrderID, driver, orderNumber);

            clickObject(orderSearch.btnGoSearch, driver);
        }
        catch(Exception e){

            e.printStackTrace();

        }
    }


    public void Cancel(WebDriver driver) {

        searchOrder search = new searchOrder(driver);

        try{

            driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));

            clickObject(search.checkBoxAll, driver);
            clickObject(search.btnCancelSelected, driver);
            //selectOrder  select = new selectOrder(driver);
            //clickObject(select.btnCancel, driver);

        }
        catch(Exception e){
            e.printStackTrace();
        }

    }

    public void PopupMessage(WebDriver driver){
        if(driver.switchTo().alert().getText().contains("Are you sure")){
            System.out.println("popup message appears");
        }
    }

    public void ClicksOnPopupOk(WebDriver driver){
        driver.switchTo().alert().accept();
    }

    public void SuccessfullyCancelled(WebDriver driver){
        itinerary del = new itinerary(driver);

        if(del.DeleteConfirmation.isDisplayed()){
            System.out.println("Booking has been successfully cancelled.");
        }
    }

    public  void logout (WebDriver driver)  {
        logOut logout = new logOut(driver);
        //filename = repo.CaptureScreenShot(driver);

        try {
            clickObject(logout.logout,driver);
        }
        catch (Exception e) {
            System.out.println("unsuccessfully logged out,Errors" + e.getMessage());
        }
        clickObject(logout.click,driver);
    }

    public void logoutSuccessful(WebDriver driver){
        logOut logout = new logOut(driver);
        if(logout.click.isDisplayed()){
            System.out.println("Logout was Successful");
        }
        else{
            System.out.println("Logout was Unsuccessful");
        }
    }

}
