package training.data;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class data {


    public ResultSet ConnectAndQuerySQL(String sDBURL, String sUserName, String sPassword, String sQuery) {

        ResultSet rs = null;
        Connection conn;
        try {

            String dbURL = sDBURL;
            String user = sUserName;
            String pass = sPassword;
            conn = DriverManager.getConnection(dbURL, user, pass);
            Statement stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            rs = stmt.executeQuery(sQuery);
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return rs;
    }

    private static int Recnum = 1;

    public int rowCount(ResultSet resultset) throws Exception {
        int count = 0;
        try {
            resultset.last();
            count = resultset.getRow();
            resultset.beforeFirst();
        } catch (Exception e) {

        }
        return count;
    }

}
