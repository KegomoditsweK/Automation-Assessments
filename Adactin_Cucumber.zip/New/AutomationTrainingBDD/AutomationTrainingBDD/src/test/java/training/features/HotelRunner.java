package training.features;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import cucumber.api.testng.AbstractTestNGCucumberTests;
import org.junit.Before;
import org.junit.runner.RunWith;
import org.testng.annotations.Parameters;
import training.WebUtilities.webUtilities;

@RunWith(Cucumber.class)
@CucumberOptions
        (features="src/test/java/training/features/BookHotel.feature",
        format = {"json:target/cucumber.json","html:target/site/cucumber-pretty"},
        glue={"training.stepdefinition", "training.features"},
        tags = {"@run1"},
        monochrome = true

)

public class HotelRunner extends AbstractTestNGCucumberTests {
}
