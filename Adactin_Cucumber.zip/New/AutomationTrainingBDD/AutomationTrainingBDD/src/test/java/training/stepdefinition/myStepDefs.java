package training.stepdefinition;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import training.PageObjects.WebFunctions;
import training.WebUtilities.webUtilities;
import training.data.data;

import java.io.FileReader;
import java.io.IOException;
import java.sql.ResultSet;
import java.util.Properties;


public class myStepDefs {

    webUtilities web = new webUtilities();
    WebFunctions adactin = new WebFunctions();
    data dat = new data();





    @Given("^a user launches and navigates to the Adactin web page")
    public void a_user_launches_and_navigates_to_the_Adactin_web_page() throws InterruptedException, IOException {
        FileReader reader=new FileReader("src/main/resources/web.properties");
        Properties p=new Properties();
        p.load(reader);

        web.setWebDriver(web.initializeWebDriver(p.getProperty("browser")));
        web.navigate(p.getProperty("url"));
    }

    @When("^a user enters the username and password and clicks login$")
    public void a_user_enters_the_and_and_clicks_login() {

        ResultSet rs;
        try {
            rs = dat.ConnectAndQuerySQL("jdbc:mysql://localhost:3306/login", "root", "7Avery!!", "SELECT * FROM login");
            int iRow = dat.rowCount(rs);
            for (int i=1;i<=iRow;i++) {
                if (rs.next()) {
                    adactin.Login(web.getWebDriver(), rs);

                }
            }rs.close();

        } catch (Exception e) {
            System.out.println("An error has occurred" +e.getMessage());
        }
    }

    @When("^a user populates fields in the search page and clicks continue$")
    public void a_user_populates_fields_in_the_search_page_and_clicks_continue()  {
        ResultSet rs;
    try{
        rs = dat.ConnectAndQuerySQL("jdbc:mysql://localhost:3306/adactin", "root", "7Avery!!", "SELECT * FROM adactin");

        while(rs.next())
           adactin.search(web.getWebDriver(), rs);
       }
       //rs.beforeFirst();
       catch(Exception e) {
           System.out.println("An error has occurred "+ e.getMessage());
       }
    }

    @And("^a user selects a hotel from the selection page and click continue$")
    public void a_user_selects_a_hotel_from_the_selection_page_and_click_continue() {
        adactin.sel_Hotel(web.getWebDriver());
    }

    @When("^a user populates the book with valid data and clicks confirm$")
    public void a_user_populates_the_book_with_valid_data_and_clicks_confirm() throws IOException {

        ResultSet rs;
    try {
        rs = dat.ConnectAndQuerySQL("jdbc:mysql://localhost:3306/adactin", "root", "7Avery!!", "SELECT * FROM adactin");
        int iRow = dat.rowCount(rs);
        for (int i=1;i<=iRow;i++) {
            if (rs.next()) {
                adactin.Book_hotel(web.getWebDriver(), rs);
            }
        }rs.close();

        } catch (Exception e) {
            System.out.println("An error has occurred" +e.getMessage());
        }
    }

    @Then("^a order is generated and the booking is successful$")
    public void a_order_is_generated_and_the_booking_is_successful() throws IOException {
        adactin.orderNumGenerated(web.getWebDriver());

    }

   @And("^Clicks on Booked Itinerary$")
    public void clicks_on_Booked_Itinerary()  {
         adactin.BookedItinerary(web.getWebDriver());

    }

    @When("^enters order number for a recently booked existing order and clicks on search$")
    public void entersOrderNumberForARecentlyBookedExistingOrderAndClicksOnSearch() throws Exception {

        try{adactin.SearchOrderNumber(web.getWebDriver());
        }
        catch(Exception e) {
            e.printStackTrace();
        }

    }


    @When("^a booking record is displayed on the table,the user selects the booking checkbox$")
    public void aBookingRecordIsDisplayedOnTheTableTheUserSelectsTheCheckBox() {
        adactin.sel_Hotel(web.getWebDriver());
    }

    @And("^a user clicks on cancel selected$")
    public void aUserClicksOnCancelSelected() {
           adactin.Cancel(web.getWebDriver());
    }


    @Then("^a confirm cancel popup message appears$")
    public void aConfirmCancelPopupMessageAppears() {
        adactin.PopupMessage(web.getWebDriver());
    }


    @When("^a user clicks on ok$")
    public void aUserClicksOnOk() {
        adactin.ClicksOnPopupOk(web.getWebDriver());
    }

    @Then("^booking is successfully cancelled$")
    public void bookingIsSuccessfullyCancelled() {
        adactin.SuccessfullyCancelled(web.getWebDriver());
    }

    @Then("^a user clicks logout$")
    public void a_user_clicks_logout()  {
        adactin.logout(web.getWebDriver());
    }

    @Then("^a user is successfully logged out$")
    public void a_user_is_successfully_logged_out()  {
        adactin.logoutSuccessful(web.getWebDriver());
        web.getWebDriver().quit();
    }
}
