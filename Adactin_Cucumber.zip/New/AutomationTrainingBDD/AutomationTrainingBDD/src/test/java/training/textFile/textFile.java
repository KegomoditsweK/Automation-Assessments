package training.textFile;

import java.io.*;

public class textFile {

    public void writeToFile(String orderNumber) {

        try{

            BufferedWriter writer = new BufferedWriter(new FileWriter("src/main/resources/orderNumber.txt"));
            writer.write(String.valueOf(orderNumber));
            writer.close();

        }
        catch(IOException e){
            e.printStackTrace();
        }
    }

    public String readFromFile() {

       String orderNum = null;
       try {

           BufferedReader reader = new BufferedReader(new FileReader("src/main/resources/orderNumber.txt"));
          String line;
           while((line=reader.readLine())!=null){
               System.out.println(line);
           }
           //reader.readLine();
           orderNum=reader.readLine();
           reader.close();

       } catch (IOException e) {
           e.printStackTrace();
       }

       return orderNum;
   }
}



