package AssessmentTwo.webPageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

public class careerPostPage {

    protected WebDriver driver;

    public careerPostPage(WebDriver driver){
        this.driver = driver;
        PageFactory.initElements(driver, this);
        PageFactory.initElements(new AjaxElementLocatorFactory(driver, 3),this);
    }

    @FindBy(xpath ="//a[contains(text(),'Interns - BSC Computer Science, National Diploma: ')]")
    public WebElement careerPost;


    //validation
    @FindBy(xpath ="//h3[normalize-space()='Description']")
    public WebElement valDescription;
}
