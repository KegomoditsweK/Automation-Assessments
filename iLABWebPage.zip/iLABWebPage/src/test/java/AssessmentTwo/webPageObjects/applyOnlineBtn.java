package AssessmentTwo.webPageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

public class applyOnlineBtn

{

        protected WebDriver driver;

        public applyOnlineBtn(WebDriver driver){
            this.driver = driver;
            PageFactory.initElements(driver, this);
            PageFactory.initElements(new AjaxElementLocatorFactory(driver, 3), this);
        }

        @FindBy(xpath = "//a[@class='wpjb-button wpjb-form-toggle wpjb-form-job-apply']")
        public WebElement apply_online;


        //validation

        @FindBy(xpath = "//h3[text()[contains(.,'CURRENT OPENINGS')]]")
        public WebElement vali_apply_online;




}
