package AssessmentTwo.webPageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;


public class homePage {

    protected WebDriver driver;

    public homePage(WebDriver driver){
        this.driver = driver;
        PageFactory.initElements(driver, this);
        PageFactory.initElements(new AjaxElementLocatorFactory(driver,3 ), this);
    }

    @FindBy(xpath = "//*[@id=\"menu-item-1373\"]")
    public WebElement careers;

    //a[text()[contains(.,'Logout')]]

    //validation
    @FindBy(xpath = "//h4[@class='vc_custom_heading vc_custom_1467312319980']")
    public WebElement valCareers;



}
