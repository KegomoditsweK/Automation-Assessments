package AssessmentTwo.webPageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

public class countryPage {

    protected WebDriver driver;
    public countryPage(WebDriver driver){
        this.driver = driver;
        PageFactory.initElements(driver, this);
        PageFactory.initElements(new AjaxElementLocatorFactory(driver, 3), this);
    }

    @FindBy(xpath = "//a[text()[contains(.,'South Africa')]]")
    public WebElement saLink;


    //validation
    @FindBy(xpath =" //h3[normalize-space()='CURRENT OPENINGS']")
    public WebElement valCurrentOpenings;




}
