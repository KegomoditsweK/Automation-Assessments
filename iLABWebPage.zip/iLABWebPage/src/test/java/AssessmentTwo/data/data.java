package AssessmentTwo.data;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class data {
    public ResultSet ConnectAndQuerySQL(String sDBURL, String sUsername, String sPassword, String sQuery) throws SQLException {

        ResultSet rs = null;

        try{
            String dbUrl = sDBURL;
            String username = sUsername;
            String password = sPassword;
            String query = sQuery;

            java.sql.Connection con = DriverManager.getConnection(dbUrl, username, password);
            Statement statement = con.createStatement();
            rs = statement.executeQuery(sQuery);

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return rs;
        }

    public int rowCount(ResultSet resultset) throws Exception {
        int count = 0;
        resultset.last();
        count = resultset.getRow();
        resultset.beforeFirst();
        return count;
    }

}
