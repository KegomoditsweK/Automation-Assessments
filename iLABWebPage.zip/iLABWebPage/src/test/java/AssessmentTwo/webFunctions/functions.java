package AssessmentTwo.webFunctions;

import AssessmentTwo.extentReport.reporting;
import AssessmentTwo.generateNumber.phoneNumber;
import AssessmentTwo.ilabUtilities.actions;
import AssessmentTwo.webPageObjects.*;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import org.openqa.selenium.WebDriver;
import java.io.IOException;
import java.sql.ResultSet;
import java.util.concurrent.TimeUnit;

public class functions extends actions {
    reporting repo = new reporting();


    public void careersLink(WebDriver driver, ExtentTest test) {
        homePage home = new homePage(driver);

        try {
            driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
            clickObject(home.careers, driver);
            String filename = repo.CaptureScreenShot(driver);


            if (home.valCareers.isDisplayed()) {
                test.pass("Career link was unsuccessful clicked", MediaEntityBuilder.createScreenCaptureFromBase64String(filename).build());
                //System.out.println("Career link click was successfully ");
            }
            else {
                test.pass("Career link was unsuccessful clicked", MediaEntityBuilder.createScreenCaptureFromBase64String(filename).build());
               // test.fail("Unsuccessful careers tab not clicked",MediaEntityBuilder.createScreenCaptureFromBase64String(filename).build());
            }
        }
        catch (Exception e) {
            System.out.println("Career link click was unsuccessful, Error: " + e.getMessage());
        }
    }

    public void countryLink(WebDriver driver, ExtentTest test) throws IOException {
        countryPage country = new countryPage(driver);
        String filename = repo.CaptureScreenShot(driver);

        try {
            driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);

            clickObject(country.saLink, driver);

            if (country.valCurrentOpenings.isDisplayed()) {
                test.pass("South Africa' link click was successful ", MediaEntityBuilder.createScreenCaptureFromBase64String(filename).build());

            }
            else {
                test.fail("South Africa' link click was unsuccessful", MediaEntityBuilder.createScreenCaptureFromBase64String(filename).build());
            }
        }
        catch (Exception e) {
          System.out.println("'South Africa' link click was successfully, Error: " + e.getMessage());
        }
    }


    public void currentOpening(WebDriver driver, ExtentTest test) throws Exception {
        careerPostPage post = new careerPostPage(driver);
        String filename = repo.CaptureScreenShot(driver);

        try {
            driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
            clickObject(post.careerPost, driver);

            if (post.valDescription.isDisplayed()) {
                test.pass("Intern-BSc Computer Science, National Diploma: IT Development  Graduates' link click was successful",MediaEntityBuilder.createScreenCaptureFromBase64String(filename).build());
            }
            else {
                test.fail("Intern-BSc Computer Science, National Diploma: IT Development  Graduates' link click was unsuccessful",MediaEntityBuilder.createScreenCaptureFromBase64String(filename).build());
            }
        } catch (Exception e) {
            System.out.println("'Intern-BSc Computer Science, National Diploma: IT Development  Graduates' link click was unsuccessfully, Error: " + e.getMessage());
        }
    }


    public void btnApplication(WebDriver driver, ExtentTest test) throws Exception {
        applyOnlineBtn applyOnline = new applyOnlineBtn(driver);
        String filename = repo.CaptureScreenShot(driver);

        try {
            driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
            clickObject(applyOnline.apply_online, driver);

            if(applyOnline.vali_apply_online.isDisplayed()){
                test.pass("Apply Online' link click was successful",MediaEntityBuilder.createScreenCaptureFromBase64String(filename).build());
            }
            else {
                test.pass("Apply Online' link click was unsuccessful",MediaEntityBuilder.createScreenCaptureFromBase64String(filename).build());
            }
        }
        catch (Exception e) {
            System.out.println("'Apply Online' link click was unsuccessful, Error: " + e.getMessage());
        }
    }

    public void application(WebDriver driver, ResultSet rs, ExtentTest test) throws Exception {
        applicationPage apply = new applicationPage(driver);
        phoneNumber phone = new phoneNumber();
        String filename = repo.CaptureScreenShot(driver);

        try {

            driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);

            sendKeysObject(apply.applicant_name, driver, rs.getString("Name"));
            sendKeysObject(apply.email, driver, rs.getString("Email"));
            sendKeysObject(apply.phone, driver, phone.getRandomNumberString());
            sendKeysObject(apply.message, driver, rs.getString("Message"));
            clickObject(apply.submit, driver);

            if(apply.uploadError.isDisplayed())
            {
                test.pass("You need to upload at least one file ",MediaEntityBuilder.createScreenCaptureFromBase64String(filename).build());
            }
            else {
                test.fail("You need to upload at least one file ",MediaEntityBuilder.createScreenCaptureFromBase64String(filename).build());
            }
        } catch (Exception e) {
            System.out.println("You need to upload at least one file." + e.getMessage());
         //   Assert.fail("You need to upload at least one file.");

        }
    }
}


