package AssessmentTwo.generateNumber;

import java.util.Random;

public class phoneNumber {

    public static String getRandomNumberString() {

        Random rand = new Random();
        int num1 = 0;
        int []arr ={6,7,8};
        int num2 = rand.nextInt(arr.length);
        int num3 = rand.nextInt(999);
        int num4 = rand.nextInt(9999);

        // this will convert any number sequence into 6 character.
        return String.format("%01d%02d %03d %04d", num1, num2, num3, num4);

   }
}
