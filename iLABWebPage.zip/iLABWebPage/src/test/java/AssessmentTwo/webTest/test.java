package AssessmentTwo.webTest;

import AssessmentTwo.data.data;
import AssessmentTwo.extentReport.reporting;
import AssessmentTwo.ilabUtilities.utilities;
import AssessmentTwo.webFunctions.functions;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.concurrent.TimeUnit;

public class test {

    public utilities web = new utilities();
    public functions func = new functions();
    public reporting repo = new reporting ();

    String   browser, url;
    ExtentReports reports;

    data data = new data();
    ResultSet rs;


    @BeforeTest
    @Parameters ({"Browser", "iLab"})
    public void beforeMethod(String sBrowser, String sUrl){

        browser = sBrowser;
         url = sUrl;
         web.setWebDriver(web.initalizeWebDriver(sBrowser));
        reports = repo.initializeExtentReports("reports/test.html");


    }
    @Test
    public void testWebsite() throws  Exception, SQLException {
        ExtentTest test = reports.createTest("iLab page");
        test.assignAuthor("Kegomoditswe Khakhane");

        try{

            rs = data.ConnectAndQuerySQL("jdbc:mysql://localhost:3306/ilabweb","root","7Avery!!","select * from ilabdata");

            int iRow = data.rowCount(rs);
            web.navigate(url);
            for (int i = 1; i <= iRow; i++) {
                if (rs.next()) {
                   func.careersLink(web.getWebDriver(), test); //Positive Test
                   func.countryLink(web.getWebDriver(), test); //Positive Test
                   func.currentOpening(web.getWebDriver(), test); //Positive Test
                   func.btnApplication(web.getWebDriver(), test); //Positive Test
                   func.application(web.getWebDriver(), rs, test); //Negative Test

                }
        }
            rs.close();

        }catch(Exception e){
            System.out.println("Error: "+e.getMessage());
        }
    }
    @AfterTest
    public void afterMethod() throws InterruptedException {

        Thread.sleep(5000);
        web.getWebDriver().quit();
        reports.flush();
    }












}
